"""Rule-based Failure Analysis Chatbot for BurnInGuard AI 2.0.

Uses the pipeline's measured values, risk signals, drift predictions and
explanation fields to answer operator questions without requiring an external
LLM or API key.
"""
import math

PARAM_LABELS = {
    "iddq_uA": "IDDQ current",
    "leakage_uA": "leakage current",
    "delay_ns": "propagation delay",
}


def _num(row, key, default=0.0):
    try:
        value = float(row.get(key, default))
        return value if math.isfinite(value) else default
    except (TypeError, ValueError):
        return default


def _pct_change(row, p):
    start = _num(row, f"{p}_0h")
    last = _num(row, f"{p}_last")
    if abs(start) < 1e-12:
        return 0.0
    return (last - start) / abs(start) * 100.0


def explain_dut(row):
    """Return a detailed, evidence-based explanation for one DUT."""
    band = str(row.get("risk_band", "UNKNOWN"))
    score = _num(row, "risk_score")
    confidence = _num(row, "risk_confidence_pct")
    anomaly = _num(row, "anomaly_ensemble_score")

    changes = {p: _pct_change(row, p) for p in PARAM_LABELS}
    largest_p = max(changes, key=lambda p: abs(changes[p]))

    margin_items = []
    for p, label in PARAM_LABELS.items():
        margin = _num(row, f"{p}_margin_pct_500h", 100.0)
        projected = _num(row, f"{p}_projected_500h")
        margin_items.append((margin, p, label, projected))
    margin_items.sort(key=lambda x: x[0])

    lines = [
        f"**{row.get('dut_id', 'Selected DUT')}** is currently **{band} risk** "
        f"with a risk score of **{score:.1f}/100** and confidence of **{confidence:.0f}%**.",
    ]

    if anomaly >= 0.60:
        lines.append(
            f"The anomaly signal is elevated (**{anomaly:.2f}**), meaning the DUT's "
            "behaviour differs noticeably from the normal pattern used by the detector."
        )
    else:
        lines.append(
            f"The anomaly signal is relatively low (**{anomaly:.2f}**), so the risk is "
            "likely being driven more by drift, lot deviation, or future margin."
        )

    lines.append(
        f"The largest relative change among the monitored parameters is **{PARAM_LABELS[largest_p]}** "
        f"at **{changes[largest_p]:+.1f}%** from 0h to the latest checkpoint."
    )

    worst_margin, p, label, projected = margin_items[0]
    if worst_margin < 0:
        lines.append(
            f"At the 500h digital-twin projection, **{label}** is projected to be "
            f"{projected:.3g}, which is beyond its configured limit."
        )
    else:
        lines.append(
            f"The tightest projected 500h margin is for **{label}** at **{worst_margin:.1f}%**."
        )

    explanation = str(row.get("explanation", "")).strip()
    if explanation:
        lines.append(f"Pipeline explanation: {explanation}")

    return "\n\n".join(lines)


def answer_question(question, row, results=None, chat_history=None):
    """Answer questions about the selected DUT or the complete DUT fleet."""
    # Fleet-level questions use the complete pipeline results table.
    # Follow-up phrases such as "List them" use the previous user question
    # to resolve what "them" refers to.
    if results is not None:
        q_fleet = (question or "").lower().strip()
        fleet_terms = [
            "how many", "how much", "number of", "count", "total",
            "percentage", "percent", "all dut", "all duts", "fleet",
            "good condition", "normal condition", "normal duts", "good duts",
            "high risk duts", "critical duts", "medium risk duts",
            "list", "show", "which dut", "which duts", "give me the duts",
            "give me all", "names of", "them", "those", "these"
        ]
        if any(term in q_fleet for term in fleet_terms):
            total = len(results)
            low = int((results["risk_band"] == "LOW").sum())
            medium = int((results["risk_band"] == "MEDIUM").sum())
            high = int((results["risk_band"] == "HIGH").sum())
            critical = int((results["risk_band"] == "CRITICAL").sum())
            risky = high + critical

            def list_duts(bands):
                subset = results[results["risk_band"].isin(bands)].sort_values(
                    "risk_score", ascending=False
                )
                if subset.empty:
                    return "No DUTs match that condition."
                lines = [f"**DUT list ({len(subset)}):**"]
                for _, item in subset.iterrows():
                    lines.append(
                        f"- **{item['dut_id']}** — {item['risk_band']} risk, "
                        f"score **{_num(item, 'risk_score'):.1f}/100**, "
                        f"confidence **{_num(item, 'risk_confidence_pct'):.0f}%**"
                    )
                return "\n".join(lines)

            # Explicit listing questions should return the actual DUT IDs.
            wants_list = any(term in q_fleet for term in [
                "list", "show", "which dut", "which duts", "give me the duts",
                "give me all", "names of", "them", "those", "these"
            ])

            # Resolve follow-ups like "List them" from the previous user turn.
            previous_question = ""
            if chat_history:
                for previous in reversed(chat_history):
                    if isinstance(previous, dict):
                        previous_question = str(previous.get("user", "")).lower()
                    elif isinstance(previous, (tuple, list)) and previous:
                        previous_question = str(previous[0]).lower()
                    if previous_question:
                        break
            combined = q_fleet + " " + previous_question

            if wants_list:
                if "critical" in combined:
                    return list_duts(["CRITICAL"])
                if "high" in combined and "risky" not in combined:
                    return list_duts(["HIGH"])
                if "medium" in combined:
                    return list_duts(["MEDIUM"])
                if "low" in combined or "good" in combined or "normal" in combined:
                    return list_duts(["LOW"])
                if "risky" in combined or "risk" in combined or "defect" in combined or "failure" in combined:
                    return list_duts(["HIGH", "CRITICAL"])
                return list_duts(["LOW", "MEDIUM", "HIGH", "CRITICAL"])

            if any(term in q_fleet for term in ["good condition", "good duts", "normal condition", "normal duts"]):
                pct = (low / total * 100) if total else 0
                return f"There are **{low} DUTs in good condition (LOW risk)** out of **{total} total DUTs** ({pct:.1f}%)."
            if "critical" in q_fleet:
                pct = (critical / total * 100) if total else 0
                return f"There are **{critical} CRITICAL-risk DUTs** out of **{total} total DUTs** ({pct:.1f}%)."
            if "high" in q_fleet:
                pct = (high / total * 100) if total else 0
                return f"There are **{high} HIGH-risk DUTs** out of **{total} total DUTs** ({pct:.1f}%)."
            if "medium" in q_fleet:
                pct = (medium / total * 100) if total else 0
                return f"There are **{medium} MEDIUM-risk DUTs** out of **{total} total DUTs** ({pct:.1f}%)."
            if any(term in q_fleet for term in ["risky", "risk", "defect", "failure"]):
                pct = (risky / total * 100) if total else 0
                return f"There are **{risky} HIGH/CRITICAL-risk DUTs** out of **{total} total DUTs** ({pct:.1f}%)."
            return (
                f"The fleet contains **{total} DUTs**: **{low} LOW**, **{medium} MEDIUM**, "
                f"**{high} HIGH**, and **{critical} CRITICAL**."
            )

    q = (question or "").lower().strip()

    # Friendly conversational replies.
    greetings = {"hi", "hello", "hey", "hii", "good morning", "good afternoon", "good evening"}
    if q in greetings:
        return "Hello! I’m **COSMO**, your BurnInGuard AI assistant.\n\nI can explain DUT risk, parameters, 500h projections, model scores, and fleet status."

    # Keep explanations short when the operator explicitly asks for a brief answer.
    brief = any(term in q for term in ["2 lines", "two lines", "2 line", "three lines", "3 lines", "brief", "short explanation", "in short"])
    if brief and any(word in q for word in ["explain", "why", "reason", "risk"]):
        band = str(row.get("risk_band", "UNKNOWN"))
        score = _num(row, "risk_score")
        anomaly = _num(row, "anomaly_ensemble_score")
        return (f"**{row.get('dut_id', 'Selected DUT')}** is **{band} risk** with a score of **{score:.1f}/100**.\n\n"
                f"The anomaly signal is **{anomaly:.2f}**, indicating how different its behaviour is from the normal pattern.")

    if not q:
        return "Ask me why the DUT is risky, which parameter is causing the problem, what may happen at 500h, or how the model made its decision."

    if any(word in q for word in ["why", "reason", "cause", "risk", "flag", "defect"]):
        return explain_dut(row)

    if any(word in q for word in ["parameter", "iddq", "leakage", "delay", "which"]):
        changes = {p: _pct_change(row, p) for p in PARAM_LABELS}
        p = max(changes, key=lambda x: abs(changes[x]))
        return (
            f"The strongest parameter change is **{PARAM_LABELS[p]}**: "
            f"{changes[p]:+.1f}% from 0h to the latest checkpoint.\n\n"
            f"IDDQ: {changes['iddq_uA']:+.1f}%\n"
            f"Leakage: {changes['leakage_uA']:+.1f}%\n"
            f"Delay: {changes['delay_ns']:+.1f}%"
        )

    if any(word in q for word in ["500", "future", "projection", "predict", "forecast"]):
        parts = []
        for p, label in PARAM_LABELS.items():
            value = _num(row, f"{p}_projected_500h")
            margin = _num(row, f"{p}_margin_pct_500h")
            parts.append(f"**{label}**: projected {value:.3g}, remaining margin {margin:.1f}%")
        return "At the 500h digital-twin projection:\n\n" + "\n\n".join(parts)

    if any(word in q for word in ["score", "confidence", "model"]):
        return (
            f"Risk score: **{_num(row, 'risk_score'):.1f}/100**\n\n"
            f"Risk band: **{row.get('risk_band', 'UNKNOWN')}**\n\n"
            f"Confidence: **{_num(row, 'risk_confidence_pct'):.0f}%**\n\n"
            f"Anomaly score: **{_num(row, 'anomaly_ensemble_score'):.2f}**"
        )

    return (
        "I can explain the selected DUT using its actual BurnInGuard results. "
        "Try: **Why is this DUT risky?**, **Which parameter is causing the problem?**, "
        "**What happens at 500h?**, or **Explain the model score.**"
    )
